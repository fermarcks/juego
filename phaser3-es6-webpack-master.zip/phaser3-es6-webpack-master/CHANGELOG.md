## Kind of a changelog

#### 2018-09-10
- Phaser 3.12
- Babel 7
- Leaving the source code introduced some issues. If you want to help out, check out this thread at HTML5GAMEDEVS: http://www.html5gamedevs.com/topic/35471-generic-platformer-es6-webpack-4-boilerplate/

#### 2018-06-02
- Webpack 4! 
- Attract mode is working again, and the online demo was updated

#### 2018-06-01
- Fire flowers and fire balls in a pool. Nice

#### 2018-05-30
- Forgot this had a changelog. Stuff such as title screen and attract mode was done without a note.
- Phaser 3.9.0 and Animated Tiles 2.0.2
- Added touch on title screen (touch controls during game play was already implemented but never reached after title screen was added :-/)
- Fixed pixel art
- Broke Attract Mode. Something physics related changed in Phaser and the json recording I use just don't work anymore.
- Reorganized the code base and started to make it cleaner.

#### 2018-02-04
- Added a flag in the end of the level
- Fixed volume for sound effects

#### 2018-02-03
- HUD: Score and Time.
- Hurry up music.
- Variable jump height.
- Toggle 16-bit / 8-bit

#### 2018-02-02
Sound effects. Phaser 3 Beta 20.

#### 2018-02-01
First version of platformer example released.